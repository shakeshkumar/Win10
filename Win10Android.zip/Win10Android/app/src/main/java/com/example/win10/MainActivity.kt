package com.example.win10

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.text.InputType
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var desk: WebView
    private lateinit var browser: WebView
    private lateinit var panel: LinearLayout
    private lateinit var addr: EditText

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    private fun setup(w: WebView) {
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
    }

    private fun norm(q: String): String {
        val t = q.trim()
        return when {
            Regex("^https?://.*", RegexOption.IGNORE_CASE).matches(t) -> t
            !t.contains(' ') && Regex("^[\\w-]+(\\.[\\w-]+)+(:\\d+)?(/\\S*)?$").matches(t) -> "https://$t"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(t, "UTF-8")
        }
    }

    private fun tb(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; minWidth = 0; minimumWidth = dp(44)
        setOnClickListener { action() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)

        // Desktop (the Windows 10 page from assets)
        desk = WebView(this)
        setup(desk)
        desk.addJavascriptInterface(Bridge(), "Android")
        desk.loadUrl("file:///android_asset/win10.html")
        root.addView(desk, FrameLayout.LayoutParams(-1, -1))

        // Real in-app browser (a full WebView, so normal sites work)
        browser = WebView(this)
        setup(browser)
        browser.settings.setSupportZoom(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser, true)
        browser.webChromeClient = WebChromeClient()
        browser.settings.allowFileAccess = true
        browser.setDownloadListener { url, ua, cd, mime, _ ->
            if (url.startsWith("http")) {
                try {
                    val name = URLUtil.guessFileName(url, cd, mime)
                    val req = DownloadManager.Request(Uri.parse(url))
                        .setMimeType(mime)
                        .addRequestHeader("User-Agent", ua)
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
                    CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
                    (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                    Toast.makeText(this, "Downloading: $name", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show()
                }
            } else Toast.makeText(this, "This file type cannot be opened inside the app", Toast.LENGTH_LONG).show()
        }
        browser.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean {
                val s = r?.url?.scheme ?: return true
                return s != "http" && s != "https"
            }
            override fun onPageStarted(v: WebView?, url: String?, f: Bitmap?) { addr.setText(url) }
        }

        addr = EditText(this).apply {
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            hint = "Search Google or type a URL"
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_GO) { browser.loadUrl(norm(text.toString())); true } else false
            }
        }
        val bar = LinearLayout(this).apply {
            setBackgroundColor(Color.parseColor("#DEE1E6"))
            addView(tb("←") { if (browser.canGoBack()) browser.goBack() })
            addView(tb("→") { if (browser.canGoForward()) browser.goForward() })
            addView(tb("⟳") { browser.reload() })
            addView(addr, LinearLayout.LayoutParams(0, -2, 1f))
            addView(tb("✕") { panel.visibility = View.GONE })
        }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            visibility = View.GONE
            addView(bar, LinearLayout.LayoutParams(-1, -2))
            addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        // leave the 44dp Windows taskbar visible underneath
        root.addView(panel, FrameLayout.LayoutParams(-1, -1).apply { bottomMargin = dp(44) })
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (panel.visibility == View.VISIBLE) {
                    if (browser.canGoBack()) browser.goBack() else panel.visibility = View.GONE
                } else finish()
            }
        })
    }

    private fun dlDir() = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)

    inner class Bridge {
        @JavascriptInterface
        fun files(): String {
            val a = JSONArray()
            dlDir()?.listFiles()?.sortedByDescending { it.lastModified() }?.forEach {
                a.put(JSONObject().put("n", it.name).put("s", it.length()))
            }
            return a.toString()
        }

        @JavascriptInterface
        fun openFile(n: String) {
            val f = File(dlDir(), File(n).name)
            if (f.exists()) runOnUiThread {
                panel.visibility = View.VISIBLE
                browser.loadUrl(Uri.fromFile(f).toString())
            }
        }

        @JavascriptInterface
        fun delFile(n: String) { File(dlDir(), File(n).name).delete() }
        @JavascriptInterface
        fun open(u: String) {
            if (u.startsWith("http://") || u.startsWith("https://")) runOnUiThread {
                panel.visibility = View.VISIBLE
                browser.loadUrl(u)
            }
        }
    }
}
